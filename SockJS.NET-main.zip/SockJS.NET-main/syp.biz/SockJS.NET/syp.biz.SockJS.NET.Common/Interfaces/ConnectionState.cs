﻿namespace syp.biz.SockJS.NET.Common.Interfaces
{
    public enum ConnectionState
    {
        Initial,
        Connecting,
        Established,
        Disconnected,
        Error
    }
}