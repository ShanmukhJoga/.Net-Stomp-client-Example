# RUNNING THE SERVER

## INSTALL DEPENDENCIES

```
npm install
```

## START SERVER

```
npm start
```

## REQUIREMENTS
- node.js v8+